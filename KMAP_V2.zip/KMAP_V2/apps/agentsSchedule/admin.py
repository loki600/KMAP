from django.contrib import admin

from .models import Agentshift, Shift

admin.site.register(Agentshift)
admin.site.register(Shift)